-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2023 at 03:39 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `andrean`
--

-- --------------------------------------------------------

--
-- Table structure for table `andreanpt`
--

CREATE TABLE `andreanpt` (
  `hotel0136` int(100) NOT NULL,
  `hotelnama` varchar(100) NOT NULL,
  `hotelalamat` varchar(250) NOT NULL,
  `kategori0136` varchar(150) NOT NULL,
  `hotelfoto` char(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `andreanpt`
--

INSERT INTO `andreanpt` (`hotel0136`, `hotelnama`, `hotelalamat`, `kategori0136`, `hotelfoto`) VALUES
(111, 'Jayakarta', 'Jl.Panglima Polim no 78 Jogjakarta', 'Hotel Ini terletak di daerah jalan malioboro yang dapat langsung berkunjung belanja', 'Jayakarta.jpg'),
(222, 'Mulia Hotel', 'Jl.RevolusiBarat no 98 BALI', 'Hotel ini terletak sangat strategis karena berdekatan dengan pantai kuta ,walkbeach,tempat hiburan', 'Mulia.jpg'),
(333, 'Aston', 'Jl.Tebet Raya no 87 BANDUNG', 'Hotel ini sangat strategis di bandung dikarenakan terletak dibagian tengah kota yang tidak jauh dengan jalan braga dan tempat tempat museum di bandung', 'ASTON-hotel.jpg'),
(444, 'TESSS', 'JL.TESSSSSS', 'ASFAFAFAFSAFAFAF', 'lombokhotel.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `andreanuas`
--

CREATE TABLE `andreanuas` (
  `andreanID` char(10) NOT NULL,
  `andreanKOTA` char(150) NOT NULL,
  `destinasiKODE` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `andreanuas`
--

INSERT INTO `andreanuas` (`andreanID`, `andreanKOTA`, `destinasiKODE`) VALUES
('472', 'LOMBOK', '104'),
('621', 'JAKARTA', '105'),
('745', 'BANDUNG', '103'),
('872', 'JOGJAKARTA', '101'),
('921', 'BALI', '102');

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `beritaID` char(20) NOT NULL,
  `beritajudul` char(120) NOT NULL,
  `beritaisi` char(200) NOT NULL,
  `tanggalterbit` char(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`beritaID`, `beritajudul`, `beritaisi`, `tanggalterbit`) VALUES
('111', 'Pantai Kuta terserang alien', 'Pantai kuta belakangan ini terserang alien dari luar bumi yang dipimpin langsung oleh komandan adudu berkepala kotak dari planet jupiter nan jauh disana', '11-07-2021'),
('222', 'Bangkitnya GatotKaca', 'Bangkitnya gatot kaca di candi borobudur yang dimana candi borobudur adalah tempat paling bersejarah dijogjakarta dan juga peninggalan nenek moyang', '11-04-2023'),
('333', 'Bom Braga', 'Terjadinya insiden pengeboman di jalan braga yang dimana orang orang sedang berbelanja dan bermain di sekitar jalan tersebut', '11-02-2022');

-- --------------------------------------------------------

--
-- Table structure for table `destinasiwisata`
--

CREATE TABLE `destinasiwisata` (
  `destinasiKODE` char(4) NOT NULL,
  `destinasiNAMA` varchar(20) NOT NULL,
  `kategoriKODE` char(4) NOT NULL,
  `kategoriWISATA` varchar(100) NOT NULL,
  `fotodestinasi` char(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `destinasiwisata`
--

INSERT INTO `destinasiwisata` (`destinasiKODE`, `destinasiNAMA`, `kategoriKODE`, `kategoriWISATA`, `fotodestinasi`) VALUES
('101', 'Merapi', '101', '103', 'jgj.jpg'),
('102', 'Pantai Kuta', '', '102', 'Kuta.jpeg'),
('103', 'Braga', '', '103', 'Braga.jpg'),
('104', 'Pantai Lombok', '', '104', 'lombok.jpg'),
('105', 'Monas', '', '105', 'monas.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `kategoriwisata`
--

CREATE TABLE `kategoriwisata` (
  `kategoriKODE` char(4) NOT NULL,
  `kategoriNAMA` char(25) NOT NULL,
  `kategoriKET` text NOT NULL,
  `kategoriREFERENCE` char(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategoriwisata`
--

INSERT INTO `kategoriwisata` (`kategoriKODE`, `kategoriNAMA`, `kategoriKET`, `kategoriREFERENCE`) VALUES
('101', 'JOGJA', 'MUSEUM', 'Ganasnya letusan gunung merapi memberikan jejak yang terlihat bagi semua masyarkat Indonesia khususnya Yogyakarta. Dampak letusan yang dahsyat terekam dalam memori semua penduduk kaki gunung merapi.'),
('102', 'BALI', 'PANTAI', 'Objek wisata di Kuta, Bali, berada di sebelah selatan Kota Denpasar, Indonesia.Pantai ini dekat dengan banyak tempat hiburan dan juga penginapan'),
('103', 'BANDUNG LAUTAN API', 'SEJARAH', ' Jalan Braga di Bandung, sentra perbelanjaan elit, bersejarah dan berwarna kolonial, menawarkan pengalaman unik dengan galeri seni, kafe, dan arsitektur klasik yang menarik.'),
('104', 'LOMBOK', 'PANTAI', 'Tempat pariwisata yang terletak di kecamatan Kuta sebelah selatan Kota Denpasar, Bali, Indonesia.'),
('105', 'JAKARTA', 'MUSEUM', 'MONAS ADALAH TEMPAT WARGA JAKARTA DAPAT MELIHAT PEMANDANGAN KOTA JAKARTA DI KETINGGIAN');

-- --------------------------------------------------------

--
-- Table structure for table `oleholeh`
--

CREATE TABLE `oleholeh` (
  `pusatKODE` char(4) NOT NULL,
  `pusatNAMA` char(150) NOT NULL,
  `pusatALAMAT` char(120) NOT NULL,
  `olehfoto` char(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `oleholeh`
--

INSERT INTO `oleholeh` (`pusatKODE`, `pusatNAMA`, `pusatALAMAT`, `olehfoto`) VALUES
('J123', 'PESONAJAWA', 'Jl.JOGJAKARTAJAWA', 'senen.jpg'),
('R012', 'KRISNA', 'Jl.KrisnaRaya102 BALI', 'krisna.jpg'),
('Y125', 'KARTIKA SARI', 'Jl.Asia Afrika Kartika Sari BANDUNG', 'kartikasari.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `ordertravel`
--

CREATE TABLE `ordertravel` (
  `orderKODE` char(11) NOT NULL,
  `orderNAMA` char(110) NOT NULL,
  `orderDESTINASI` char(120) NOT NULL,
  `kodeTRAVEL` char(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ordertravel`
--

INSERT INTO `ordertravel` (`orderKODE`, `orderNAMA`, `orderDESTINASI`, `kodeTRAVEL`) VALUES
('111', 'PUTRA', 'JOGJAKARTA', '77'),
('12', 'Osman', 'BALI', '04'),
('222', 'Rizky', 'BANDUNG', '88');

-- --------------------------------------------------------

--
-- Table structure for table `restorant`
--

CREATE TABLE `restorant` (
  `menuKODE` int(4) NOT NULL,
  `menuNAMA` char(120) NOT NULL,
  `menuHARGA` char(200) NOT NULL,
  `menuFOTO` char(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `restorant`
--

INSERT INTO `restorant` (`menuKODE`, `menuNAMA`, `menuHARGA`, `menuFOTO`) VALUES
(111, 'Chicken Katsu', 'Rp 80.000', '6564dc3c81f8a.jpg'),
(123, 'Sambal Terong Merah', 'Rp.30.000', '6565985409b70.jpg'),
(222, 'Sambal', 'Rp 80.000', 'burger.jpg'),
(454, 'TES', 'Rp 50.000', '656f5eed16f4f.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `travel`
--

CREATE TABLE `travel` (
  `kodeTRAVEL` char(4) NOT NULL,
  `namaTRAVEL` char(160) NOT NULL,
  `fotoTRAVEL` char(120) NOT NULL,
  `destinasiTRAVEL` char(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `travel`
--

INSERT INTO `travel` (`kodeTRAVEL`, `namaTRAVEL`, `fotoTRAVEL`, `destinasiTRAVEL`) VALUES
('421', 'GoesToLombok', 'lombok.jpg', 'Lombok'),
('77', 'Jogja Istimewa', 'jgj.jpg', 'Jogja'),
('88', 'Bandung Love', 'Braga.jpg', 'Bandung');

-- --------------------------------------------------------

--
-- Table structure for table `useradmin`
--

CREATE TABLE `useradmin` (
  `userKODE` char(4) NOT NULL,
  `userNAMA` char(30) NOT NULL,
  `userEMAIL` char(60) NOT NULL,
  `userPASS` char(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `useradmin`
--

INSERT INTO `useradmin` (`userKODE`, `userNAMA`, `userEMAIL`, `userPASS`) VALUES
('0136', 'Andrean Putra', 'andrean@gmail.com', 'b9f6e9149b713ee3704728c84b8f158c');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `andreanpt`
--
ALTER TABLE `andreanpt`
  ADD PRIMARY KEY (`hotel0136`);

--
-- Indexes for table `andreanuas`
--
ALTER TABLE `andreanuas`
  ADD PRIMARY KEY (`andreanID`);

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`beritaID`);

--
-- Indexes for table `destinasiwisata`
--
ALTER TABLE `destinasiwisata`
  ADD PRIMARY KEY (`destinasiKODE`);

--
-- Indexes for table `kategoriwisata`
--
ALTER TABLE `kategoriwisata`
  ADD PRIMARY KEY (`kategoriKODE`);

--
-- Indexes for table `oleholeh`
--
ALTER TABLE `oleholeh`
  ADD PRIMARY KEY (`pusatKODE`);

--
-- Indexes for table `ordertravel`
--
ALTER TABLE `ordertravel`
  ADD PRIMARY KEY (`orderKODE`);

--
-- Indexes for table `restorant`
--
ALTER TABLE `restorant`
  ADD PRIMARY KEY (`menuKODE`);

--
-- Indexes for table `travel`
--
ALTER TABLE `travel`
  ADD PRIMARY KEY (`kodeTRAVEL`);

--
-- Indexes for table `useradmin`
--
ALTER TABLE `useradmin`
  ADD PRIMARY KEY (`userKODE`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
