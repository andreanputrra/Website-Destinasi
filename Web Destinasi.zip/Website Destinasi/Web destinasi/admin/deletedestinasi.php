<?php
include 'include/config.php';

if(isset($_GET['hapus'])) {
    $kode_destinasi = $_GET['hapus'];

    $query = "DELETE FROM destinasiwisata WHERE destinasiKODE = '$kode_destinasi'";
    $result = mysqli_query($connection, $query);

    if($result) {
        echo "<script>alert('Data berhasil dihapus');window.location='destinasiadminpage.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus data');</script>";
    }
}
?>
