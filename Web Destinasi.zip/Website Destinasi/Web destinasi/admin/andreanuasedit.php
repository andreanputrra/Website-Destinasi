<?php
    include 'include/config.php';
    
    if(isset($_GET['ubah'])) {
        $kode_to_edit = $_GET['ubah'];
        
        $query = mysqli_query($connection, "SELECT * FROM andreanuas WHERE destinasiKODE = '$kode_to_edit'");
        $data = mysqli_fetch_assoc($query);
        
        if(!$data) {
            echo "Data not found!";
            exit;
        }
        
        if(isset($_POST['Update'])) {
            $newAndreanID = $_POST['kodedestinasi'];
            $newAndreanKOTA = $_POST['namadestinasi'];
            $newDestinasiKODE = $_POST['destinasikode'];
            
            $updateQuery = "UPDATE andreanuas SET andreanID = '$newAndreanID', andreanKOTA = '$newAndreanKOTA', destinasiKODE = '$newDestinasiKODE' WHERE destinasiKODE = '$kode_to_edit'";
            
            if(mysqli_query($connection, $updateQuery)) {
                header("Location: andreanuasdash.php"); // Redirect to desired page after successful update
                exit();
            } else {
                echo "Error updating data: " . mysqli_error($connection);
            }
        }
    } else {
        echo "No identifier provided!";
        exit;
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Data</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Edit Data</h2>
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3 row">
            <label for="kodedestinasi" class="col-sm-2 col-form-label">Kode id</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="kodedestinasi" id="kodedestinasi" value="<?php echo $data['andreanID']; ?>">
            </div>
        </div>
        <div class="mb-3 row">
            <label for="namadestinasi" class="col-sm-2 col-form-label">Nama Kota</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="namadestinasi" id="namadestinasi" value="<?php echo $data['andreanKOTA']; ?>">
            </div>
        </div>
        <div class="mb-3 row">
            <label for="destinasikode" class="col-sm-2 col-form-label">Destinasi Wisata</label>
            <div class="col-sm-10">
                <select class="form-control" name="destinasikode" id="destinasikode">
                    <?php
                        $selected_destinasiKODE = $data['destinasiKODE'];
                        $datakategori = mysqli_query($connection, "SELECT * FROM destinasiwisata");
                        while($row = mysqli_fetch_array($datakategori)) {
                            $option_value = $row["destinasiKODE"];
                            $selected = ($option_value == $selected_destinasiKODE) ? 'selected' : '';
                            echo "<option value='$option_value' $selected>" . $row["destinasiKODE"] . " " . $row["destinasiNAMA"] . "</option>";
                        }
                    ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-sm-2"></div>
            <div class="col-sm-10">
                <input type="submit" name="Update" value="Update" class="btn btn-primary">
                <a href="andreanuas.php" class="btn btn-secondary">Cancel</a>
            </div>
        </div>
    </form>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('#destinasikode').select2({
            closeOnSelect:true,
            allowClear:true,
            placeholder:'Pilih Kategori Wisata'
        });
    });
</script>

</body>
</html>
