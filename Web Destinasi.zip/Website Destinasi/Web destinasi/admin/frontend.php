<!doctype html>

<?php
    include 'include/config.php';
    $query = mysqli_query($connection, "SELECT * FROM andreanpt");

    $destinasi = mysqli_query($connection, "SELECT * FROM destinasiwisata
    JOIN kategoriwisata ON destinasiwisata.destinasiKODE = kategoriwisata.kategoriKODE");

    
    $ordertravel = mysqli_query($connection, "SELECT * FROM ordertravel
    JOIN travel ON ordertravel.kodeTRAVEL = travel.kodeTRAVEL");
    
    $hotelData = mysqli_query($connection, "SELECT * FROM andreanpt");

    $berita = mysqli_query($connection, "SELECT * FROM berita");

    $travel = mysqli_query($connection, "SELECT * FROM travel");

    $restorant = mysqli_query($connection, "SELECT * FROM restorant");

    $oleholeh = mysqli_query($connection, "SELECT * FROM oleholeh");

   
?>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>BERITA</title>
  </head>
  <body>

  <!-- MEMBUAT MENU -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="frontend.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Kategori Wisata
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <?php
        $kategoriQuery = mysqli_query($connection, "SELECT kategoriNAMA FROM kategoriwisata");
        while ($row = mysqli_fetch_array($kategoriQuery)) {
          echo '<a class="dropdown-item" href="kategoriwisatafront.php?id=' . $row['kategoriNAMA'] . '">' . $row['kategoriNAMA'] . '</a>';
        }
        ?>
    </div>
</li>
      <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Travel
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <?php
        $travelQuery = mysqli_query($connection, "SELECT namaTRAVEL FROM travel");
        while ($row = mysqli_fetch_array($travelQuery)) {
          echo '<a class="dropdown-item" href="travelindex.php?id=' . $row['namaTRAVEL'] . '">' . $row['namaTRAVEL'] . '</a>';
        }
        ?>
    </div>
</li>

      <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Resto
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <?php
        $restoQuery = mysqli_query($connection, "SELECT menuNAMA FROM restorant");
        while ($row = mysqli_fetch_array($restoQuery)) {
          echo '<a class="dropdown-item" href="restorantfront.php?id=' . $row['menuNAMA'] . '">' . $row['menuNAMA'] . '</a>';
        }
        ?>
    </div>
</li>


      <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Oleh Oleh
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <?php
        $oleholehQuery = mysqli_query($connection, "SELECT pusatNAMA, pusatALAMAT FROM oleholeh");
        while ($row = mysqli_fetch_array($oleholehQuery)) {
            echo '<a class="dropdown-item" href="oleholehfront.php">' . $row['pusatNAMA'] . '</a>';
        }
        ?>
    </div>
</li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Hotel
        </a>
        <?php
        $hotelQuery = mysqli_query($connection, "SELECT hotel0136, hotelNAMA FROM andreanpt");
        ?>

        <!-- Dropdown yang diperbarui -->
<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
<?php
// Loop untuk menampilkan data hotelNAMA sebagai opsi dropdown
while ($hotelRow = mysqli_fetch_assoc($hotelQuery)) {
  $hotelID = $hotelRow["hotel0136"];
  $hotelNAMA = $hotelRow["hotelNAMA"];
  
  // Membuat URL dengan menggunakan hotelID sebagai bagian dari href
  $href = "detailhotel.php?hotel_id=" . $hotelID;

  // Menampilkan opsi dropdown dengan href yang unik
  echo '<li><a class="dropdown-item" href="' . $href . '">' . $hotelNAMA . '</a></li>';
}
?>

</ul>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">

        <?php if(mysqli_num_rows($query) > 0) {
          while ($row = mysqli_fetch_array($query))
          { ?>
            <a class="dropdown-item" href="#"><?php echo $row["hotelnama"]?></a>
          
          <?php } } ?>
         



        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Disabled</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
  <!-- AKHIR MENU -->

    <!-- SLIDER  -->
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>


  </ol>
  <div class="carousel-inner mb-5">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/destinasiwisata.jpg" alt="First slide">
      
      <div class="carousel-caption d-none d-md-block">
        <h1>DestinasiWisata</h1>
       
      </div>
          </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/jgj.jpg" alt="Second slide">
      <div class="carousel-caption d-none d-md-block">
      <h1>Jogjakarta</h1>
        <p> JOGJA JOGJA JOGJA ISTIMEWA</p>
      </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/Kuta.jpeg" alt="Third slide">

      <div class="carousel-caption d-none d-md-block">
      <h1>Bali</h1>
      
      </div>

    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/Braga.jpg" alt="Third slide">

      <div class="carousel-caption d-none d-md-block">
      <h1>Bandung</h1>
      
      </div>

    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/lombok.jpg" alt="Third slide">

      <div class="carousel-caption d-none d-md-block">
      <h1>Lombok</h1>
      
      </div>

    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>         


      <!-- Akhir SLider -->



      <!-- Membuat Tampilan Objek -->
      <div class="container">
  <div class="row">
    <div class="col-sm-8">
      <?php if(mysqli_num_rows($destinasi) > 0) {
        while ($row2 = mysqli_fetch_array($destinasi)) { ?>
          <div class="media" style="display: flex; align-items: center;">
            <div class="media-body mb-20">
              <h4 class="mt-4 mb-10"><?php echo $row2["destinasiNAMA"]?></h4>
              <p><?php echo $row2["kategoriNAMA"]?></p>
              <p><?php echo $row2["kategoriREFERENCE"]?></p>
            </div>
            <img class="ml-5" style="width:400px; height: auto; margin-top: 35px;" src="images/<?php echo $row2["fotodestinasi"]?>" alt="Gambar menghilang">
          </div>
          <br><br>
        <?php } } ?>
    </div>

    <!-- card -->
    <div class="col-sm-3 ml-5">
    <div class="row">
        <?php
        // Pastikan ada data dari hasil query sebelum mengambilnya
        if(mysqli_num_rows($query) > 0) {
            // Ambil data dari hasil query
            $row2 = mysqli_fetch_assoc($hotelData);
        ?>
        <div class="card">
            <div class="card-body">
                <!-- Gunakan variabel yang telah didefinisikan ($row2) -->
                <h5 class="card-title"><?php echo $row2["hotelnama"]; ?></h5>
                <p class="card-text"><?php echo $row2["hotelalamat"]; ?></p>
                <img src="images/<?php echo $row2["hotelfoto"]; ?>" class="card-img-top" alt="Hotel Image">
                <a href="detailhotel.php?hotel_id=111" class="btn btn-primary mt-3">More Info</a>
            </div>
        </div>
        <?php
        } else {
            echo "Tidak ada data hotel.";
        }
        ?>
    </div>
    <div class="row">
        <?php
        // Pastikan ada data dari hasil query sebelum mengambilnya
        if(mysqli_num_rows($query) > 0) {
            // Ambil data dari hasil query
            $row2 = mysqli_fetch_assoc($hotelData);
        ?>
        <div class="card">
            <div class="card-body">
                <!-- Gunakan variabel yang telah didefinisikan ($row2) -->
                <h5 class="card-title"><?php echo $row2["hotelnama"]; ?></h5>
                <p class="card-text"><?php echo $row2["hotelalamat"]; ?></p>
                <img src="images/<?php echo $row2["hotelfoto"]; ?>" class="card-img-top" alt="Hotel Image">
                <a href="detailhotel.php?hotel_id=222" class="btn btn-primary mt-3">More Info</a>           
       
               </div>
        </div>
        <?php
        } else {
            echo "Tidak ada data hotel.";
        }
        ?>
    </div>
    <div class="row">
        <?php
        // Pastikan ada data dari hasil query sebelum mengambilnya
        if(mysqli_num_rows($query) > 0) {
            // Ambil data dari hasil query
            $row2 = mysqli_fetch_assoc($hotelData);
        ?>
        <div class="card">
            <div class="card-body">
                <!-- Gunakan variabel yang telah didefinisikan ($row2) -->
                <h5 class="card-title"><?php echo $row2["hotelnama"]; ?></h5>
                <p class="card-text"><?php echo $row2["hotelalamat"]; ?></p>
                <img src="images/<?php echo $row2["hotelfoto"]; ?>" class="card-img-top" alt="Hotel Image">
                <a href="detailhotel.php?hotel_id=333" class="btn btn-primary mt-3">More Info</a>           
               </div>
        </div>
        <?php
        } else {
            echo "Tidak ada data hotel.";
        }
        ?>
    </div>
    <div class="row">
        <?php
        // Pastikan ada data dari hasil query sebelum mengambilnya
        if(mysqli_num_rows($query) > 0) {
            // Ambil data dari hasil query
            $row2 = mysqli_fetch_assoc($hotelData);
        ?>
        <div class="card">
            <div class="card-body">
                <!-- Gunakan variabel yang telah didefinisikan ($row2) -->
                <h5 class="card-title"><?php echo $row2["hotelnama"]; ?></h5>
                <p class="card-text"><?php echo $row2["hotelalamat"]; ?></p>
                <img src="images/<?php echo $row2["hotelfoto"]; ?>" class="card-img-top" alt="Hotel Image">
                <a href="detailhotel.php?hotel_id=444" class="btn btn-primary mt-3">More Info</a>            
              </div>
        </div>
        <?php
        } else {
            echo "Tidak ada data hotel.";
        }
        ?>
    </div>
</div>


  </div>
</div>
<div class="DETAILBERITA" style="text-align: center; margin: 0 auto; width: 50%;">
<h2> BERITA </h2>

</div>





 <!-- Inner -->
 <div class="carousel-inner py-4">
    <!-- Single item -->
    <div class="carousel-item active">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="card">
            <?php
        // Pastikan ada data dari hasil query sebelum mengambilnya
        if(mysqli_num_rows($query) > 0) {
            // Ambil data dari hasil query
            $row2 = mysqli_fetch_assoc($berita);
        ?>
        <div class="card">
            <div class="card-body">
                <!-- Gunakan variabel yang telah didefinisikan ($row2) -->
                <h5 class="card-title"><?php echo $row2["beritajudul"]; ?></h5>
                <p class="card-text"><?php echo $row2["beritaisi"]; ?></p>
            </div>
        </div>
        <?php
        } else {
            echo "Tidak ada data hotel.";
        }
        ?>
       
           
            </div>
          </div>
 
          <div class="col-lg-4 d-none d-lg-block">
            <div class="card">
            <?php
        // Pastikan ada data dari hasil query sebelum mengambilnya
        if(mysqli_num_rows($query) > 0) {
            // Ambil data dari hasil query
            $row2 = mysqli_fetch_assoc($berita);
        ?>
              <div class="card-body">
                       <!-- Gunakan variabel yang telah didefinisikan ($row2) -->
              <h5 class="card-title"><?php echo $row2["beritajudul"]; ?></h5>
                <p class="card-text"><?php echo $row2["beritaisi"]; ?></p>
              </div>
              <?php
        } else {
            echo "Tidak ada data hotel.";
        }
        ?>
            </div>
          </div>
 
  
          <div class="col-lg-4 d-none d-lg-block">
            <div class="card">
            <?php
        // Pastikan ada data dari hasil query sebelum mengambilnya
        if(mysqli_num_rows($query) > 0) {
            // Ambil data dari hasil query
            $row2 = mysqli_fetch_assoc($berita);
        ?>
              <div class="card-body">
                       <!-- Gunakan variabel yang telah didefinisikan ($row2) -->
              <h5 class="card-title"><?php echo $row2["beritajudul"]; ?></h5>
                <p class="card-text"><?php echo $row2["beritaisi"]; ?></p>
              </div>
              <?php
        } else {
            echo "Tidak ada data hotel.";
        }
        ?>
            </div>
          </div>
        </div>
      </div>
    </div>
      </div>
      <div class="DETAILRESTORANT" style="text-align: center; margin: 0 auto; width: 50%;">
<h2> RESTORANT </h2>

</div>
<div class="col-sm-8 mx-auto">
  <?php if(mysqli_num_rows($restorant) > 0) {
    while ($row2 = mysqli_fetch_array($restorant)) { ?>
      <div class="card mb-4" style="border: 1px solid #ccc; border-radius: 10px; overflow: hidden;">
        <div class="row no-gutters">
          <div class="col-md-6">
            <img src="images/<?php echo $row2["menuFOTO"]?>" class="card-img" alt="Gambar">
          </div>
          <div class="col-md-6">
            <div class="card-body">
              <h3 class="card-title mt-4 mb-3"><?php echo $row2["menuNAMA"]?></h3>
              <p class="card-text">Harga: <?php echo $row2["menuHARGA"]?></p>
            </div>
          </div>
        </div>
      </div>
    <?php } } ?>
</div>


<div class="DETAILTRAVEL" style="text-align: center; margin: 0 auto; width: 50%;">
<h2> TRAVEL </h2>

</div>
<div class="col-sm-8 mx-auto">
  <?php if(mysqli_num_rows($travel) > 0) {
    while ($row2 = mysqli_fetch_array($travel)) { ?>
      <div class="media" style="display: flex; align-items: center; border: 1px solid #ddd; border-radius: 8px; overflow: hidden; margin-bottom: 20px;">
        <img class="mr-5" style="width: 40%; max-width: 300px; height: auto; object-fit: cover; border-radius: 8px 0 0 8px;" src="images/<?php echo $row2["fotoTRAVEL"]?>" alt="Gambar">
        <div class="media-body p-3">
          <h3 style="margin-top: 0; margin-bottom: 10px; font-size: 24px; font-weight: bold;"><?php echo $row2["namaTRAVEL"]?></h3>
          <p style="font-size: 16px; color: #666; margin-bottom: 15px;">Tujuan Destinasi: <?php echo $row2["destinasiTRAVEL"]?></p>
        </div>
      </div>
    <?php } } ?>
</div>


<div class="oleholeh" style="text-align: center; margin: 0 auto; width: 50%;">
<h2> Oleh Oleh </h2>

</div>
      <div class="col-sm-8 mx-auto"> <!-- Tambahkan class mx-auto di sini -->
      <?php if(mysqli_num_rows($travel) > 0) {
        while ($row2 = mysqli_fetch_array($travel)) { ?>
          <div class="media" style="display: flex; align-items: center; background-color: #f5f5f5; border-radius: 10px; padding: 20px; margin-bottom: 20px;">
            <img class="mr-5" style="width:350px; height: auto; margin-top: 10px;" src="images/<?php echo $row2["fotoTRAVEL"]?>" alt="Gambar menghilang">
            <div class="media-body mb-20">
          
              <h3 class="mt-4 mb-5"><?php echo $row2["namaTRAVEL"]?></h3>
              <p>Tujuan Destinasi: <?php echo $row2["destinasiTRAVEL"]?></p>
            </div>
          </div>
        <?php } } ?>
    </div>

    <div class="col-sm-8 mx-auto">
  <?php if(mysqli_num_rows($oleholeh) > 0) {
    while ($row2 = mysqli_fetch_array($oleholeh)) { ?>
      <div class="media-container" style="display: flex; align-items: center; background-color: #fff; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden; box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); margin-bottom: 20px;">
        <img class="media-img" style="max-width: 200px; height: auto; object-fit: cover; flex-shrink: 0; border-radius: 8px 0 0 8px;" src="images/<?php echo $row2["olehfoto"]?>" alt="Gambar">
        <div class="media-body" style="flex: 1; padding: 20px;">
          <h4 style="margin-top: 0; margin-bottom: 10px; font-size: 24px; font-weight: bold; color: #333;"><?php echo $row2["pusatNAMA"]?></h4>
          <p style="font-size: 16px; color: #666;"><?php echo $row2["pusatALAMAT"]?></p>
        </div>
      </div>
  <?php } } ?>
</div>





    <div class="oleholeh" style="text-align: center; margin: 0 auto; width: 50%;">
<h2> Travel Order </h2>
    <div class="col-sm-8 mx-auto">
    <div class="row">
        <?php
        if(mysqli_num_rows($ordertravel) > 0) {
            while ($row2 = mysqli_fetch_array($ordertravel)) {
        ?>
        <div class="col-md-6 mb-4">
            <div class="card h-100 border-primary" style="overflow: hidden; border: 1px solid #ddd; border-radius: 8px;">
                <img class="card-img-top" style="width:100%; height: 200px; object-fit: cover; transition: transform 0.5s ease;" src="images/<?php echo $row2["fotoTRAVEL"]?>" alt="Gambar menghilang" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'">
                <div class="card-body" style="padding: 20px;">
                    <h4 class="card-title mt-4 mb-3"><?php echo $row2["orderNAMA"]?></h4>
                    <p class="card-text"><?php echo $row2["orderDESTINASI"]?></p>
                    <p class="card-text">Travel Kode: <?php echo $row2["kodeTRAVEL"]?></p>
                </div>
            </div>
        </div>
        <?php
            }
        }
        ?>
    </div>
</div>


 <!-- TAMBAHAN INI DRE BUAT UJIAN GATAU BENER APA GA INGET KALO SALA APUS !-->
 
<table class="table table-hover table-dark">
<thead>
<tr>
<th scope="col">No</th>
<th scope="col">Destinasi Wisata</th>
<th scope="col">Lokasi</th>
<th scope="col">Tipe </th>
<th scope="col">Keterangan</th>
<th scope="col">Foto Lokasi</th>

</tr>
</thead>
<tbody>
<?php
if (isset($_POST["kirim_nama"])) {
    $destinasiNAMA = $_POST['search_DESTINASI'];
    $destinasi = mysqli_query($connection, "SELECT * FROM destinasiwisata
        JOIN kategoriwisata ON destinasiwisata.destinasiKODE = kategoriwisata.kategoriKODE
        WHERE destinasiwisata.destinasiNAMA LIKE '%$destinasiNAMA%'");
} elseif (isset($_POST["kirim_alamat"])) {
    $kategoriNAMA = $_POST['search_NAMA'];
    $destinasi = mysqli_query($connection, "SELECT * FROM destinasiwisata
        JOIN kategoriwisata ON destinasiwisata.destinasiKODE = kategoriwisata.kategoriKODE
        WHERE kategoriwisata.kategoriNAMA LIKE '%$kategoriNAMA%'");
} else {
    $destinasi = mysqli_query($connection, "SELECT * FROM destinasiwisata
        JOIN kategoriwisata ON destinasiwisata.destinasiKODE = kategoriwisata.kategoriKODE");
}

$nomor = 1;
while($row = mysqli_fetch_array($destinasi)) {
?>
<tr>
<td><?php echo $nomor; ?></td>
<td><?php echo $row['destinasiNAMA']; ?></td>
<td><?php echo $row['kategoriNAMA']; ?></td>
<td><?php echo $row['kategoriKET']; ?></td>
<td><?php echo $row['kategoriREFERENCE']; ?></td>
<td>
    <?php if(is_file("images/".$row['fotodestinasi']))
    { ?>
        <img src="images/<?php echo $row['fotodestinasi']?>" width="80">
    <?php } else
    echo "<img src='images/noimage.png' width='80'>"
    ?>
</td>
</tr>
<?php $nomor = $nomor + 1; ?>
<?php } ?>
</tbody>
</table>


 






      <!-- END Tampilan Objek -->
      

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>