<?php
include 'include/config.php';

if(isset($_GET['ubah'])) {
    $orderKODE = $_GET['ubah'];

    // Fetch specific order details based on orderKODE
    $query = mysqli_query($connection, "SELECT * FROM ordertravel WHERE orderKODE = '$orderKODE'");
    $row = mysqli_fetch_array($query);
    
    // If the order exists, populate the form fields
    if ($row) {
        $orderNAMA = $row['orderNAMA'];
        $orderDESTINASI = $row['orderDESTINASI'];
    } else {
        // Redirect or display an error message if the order doesn't exist
        header("Location: ordertravel.php");
        exit();
    }
}

// Process form submission for editing
if(isset($_POST['Edit'])) {
    $editedNama = $_POST['editedNama'];
    $editedDestinasi = $_POST['editedDestinasi'];

    mysqli_query($connection, "UPDATE ordertravel SET orderNAMA = '$editedNama', orderDESTINASI = '$editedDestinasi' WHERE orderKODE = '$orderKODE'");
    header("Location: ordertravel.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Order</title>
    <!-- Include your CSS and other necessary files -->
</head>
<body>
    <h2>Edit Order</h2>
    <form method="POST">
        <div>
            <label for="editedNama">Order Nama</label>
            <input type="text" name="editedNama" id="editedNama" value="<?php echo $orderNAMA; ?>">
        </div>
        <div>
            <label for="editedDestinasi">Order Destinasi</label>
            <input type="text" name="editedDestinasi" id="editedDestinasi" value="<?php echo $orderDESTINASI; ?>">
        </div>
        <input type="submit" name="Edit" value="Edit">
    </form>
</body>
</html>
