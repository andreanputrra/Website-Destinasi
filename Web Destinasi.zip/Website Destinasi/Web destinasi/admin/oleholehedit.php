<?php
    include "include/config.php";

    if(isset($_POST['Simpan'])) {
        $pusatKODE = $_POST['pusatKODE'];
        $pusatNAMA = $_POST['pusatNAMA'];
        $pusatALAMAT = $_POST['pusatALAMAT'];

        $namafile = $_FILES['file']['name'];
        $file_tmp = $_FILES["file"]["tmp_name"];

        $ekstensifile = pathinfo($namafile, PATHINFO_EXTENSION);

        if(($ekstensifile == "jpg") or ($ekstensifile == "JPG") or ($ekstensifile == "JPEG")) {
            move_uploaded_file($file_tmp, 'images/'.$namafile);
            mysqli_query($connection, "UPDATE oleholeh 
                                       SET pusatNAMA = '$pusatNAMA', 
                                           pusatALAMAT = '$pusatALAMAT', 
                                           olehfoto = '$namafile' 
                                       WHERE pusatKODE = '$pusatKODE'");
            echo '<script>alert("Update successful!"); window.location.href = "oleholehdash.php";</script>';
            exit();
        }
    }

    $olehKODE = $_GET["ubah"];
    $edit_oleh = mysqli_query($connection, "SELECT * FROM oleholeh WHERE pusatKODE = '$olehKODE'");
    $rowedit = mysqli_fetch_array($edit_oleh);
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css">
</head>
<body>
    <div class="row">
        <div class="col-sm-1"></div>
        <div class="col-sm-10">
            <header>
                <h1 style="background:black; color:white; height:80px;">Pusat Oleh-Oleh</h1>
            </header>
            <div class="row">
                <div class="col-sm-1"></div>
                <div class="col-sm-10">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3 row">
                            <label for="pusatKODE" class="col-sm-2 col-form-label">Kode Tempat</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="pusatKODE" name="pusatKODE" value="<?php echo $rowedit["pusatKODE"]; ?>">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="pusatNAMA" class="col-sm-2 col-form-label">Nama Tempat</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="pusatNAMA" name="pusatNAMA" value="<?php echo $rowedit["pusatNAMA"]; ?>">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="pusatALAMAT" class="col-sm-2 col-form-label">Alamat Tempat</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="pusatALAMAT" name="pusatALAMAT" value="<?php echo $rowedit["pusatALAMAT"]; ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="file" class="col-sm-2 col-form-label">Foto Lokasi</label>
                            <div class="col-sm-10">
                                <input type="file" id="file" name="file">
                                <p class="help-block">Field ini digunakan untuk unggah file</p>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-10">
                                <input type="submit" class="btn btn-primary" value="Simpan" name="Simpan">
                                <a href="oleholehdash.php" class="btn btn-secondary">Batal</a>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
            <!-- penutup div buat form -->
            <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
        </div>
    </div>
</body>
</html>
