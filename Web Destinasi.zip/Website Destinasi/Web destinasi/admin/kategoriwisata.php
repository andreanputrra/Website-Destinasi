<!doctype html>

<?php
include "include/config.php";
	if(isset($_POST['Simpan']))
	{	$kategoriKODE = $_POST['inputKategoriKode'];
		$kategoriNAMA = $_POST['inputKategoriNama'];
		$kategoriKET = $_POST['inputKategoriKet'];
		$kategoriREFERENCE = $_POST['inputKategoriReference'];
		
		mysqli_query($connection, "INSERT INTO kategoriwisata VALUES ('$kategoriKODE', '$kategoriNAMA', '$kategoriKET', '$kategoriREFERENCE')");
		
		
	}
?>

<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>WEBDEV KELAS C</title>
  </head>
  <body>
  
  
  
  
  <!--awal -->
  <div class="col-sm-2"></div>

<div class="col-sm-10">
    <form method="POST" action="">
        <div class="form-group row">
            <label for="kategoriKODE" class="col-sm-3 col-form-label">Kode Kategori Wisata</label>
            <div class="col-sm-7">
                <input type="text" class="form-control" id="kategoriKODE" name="inputKategoriKode" placeholder="Kode Kategori Wisata">
            </div>
        </div>

        <div class="form-group row">
            <label for="kategoriNAMA" class="col-sm-3 col-form-label">Nama Kategori Wisata</label>
            <div class="col-sm-7">
                <input type="text" class="form-control" id="kategoriNAMA" name="inputKategoriNama" placeholder="Inputkan Nama Kategori Wisata">
            </div>
        </div>

        <div class="form-group row">
            <label for="kategoriKET" class="col-sm-3 col-form-label">Keterangan Kategori Wisata</label>
            <div class="col-sm-7">
                <input type="text" class="form-control" id="kategoriKET" name="inputKategoriKet" placeholder="Keterangan Kategori Wisata">
            </div>
        </div>

        <div class="form-group row">
            <label for="kategoriREFERENCE" class="col-sm-3 col-form-label">Reference Kategori Wisata</label>
            <div class="col-sm-7">
                <input type="text" class="form-control" id="kategoriREFERENCE" name="inputKategoriReference" placeholder="Referensi Kategori Wisata">
            </div>
        </div>

        <div class="form-group row">
            <div class="col-sm-0"></div>
            <div class="col-sm-5">
                <input type="submit" name="Simpan" value="Simpan" class="btn btn-secondary">
                <input type="reset" class="btn btn-success" value="Batal" name="Batal">
            </div>
        </div>
    </form>
</div>
<br>


<!-- membuat form pencarian -->
<form method="POST">
  <div class="form-group row mb-2">
    <label for="search" class="col-sm-3">Nama Destinasi</label>
    <div class="col-sm-6">
      <input type="text" name="search" class="form-control" id="search" value="<?php if(isset($_POST['search'])) {echo $_POST['search'];}?>" placeholder="Cari Nama Kategori">
    </div>
    <input type="submit" name="kirim" class="col-sm-1 btn btn-primary" value="Search">
  </div>
</form>

<table class="table table-hover table-dark">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Kode Kategori</th>
      <th scope="col">Nama Kategori</th>
      <th scope="col">Keterangan Kategori</th>
      <th scope="col">Kode Reference</th>

      <th colspan="2" style="text-align: center">Aksi</th>

    </tr>
  </thead>
  <tbody>

<!-- menerima kiriman dari form untuk pencarian pada tabel -->
<?php
    if(isset($_POST["kirim"]))
    {
        $search = $_POST['search'];
        $query = mysqli_query($connection,"select kategoriwisata.* from kategoriwisata
            where kategoriNAMA like '%".$search."%'");
    }   else
        {
            $query = mysqli_query($connection, "select kategoriwisata.* from kategoriwisata");
        }
// end pencarian

// $query = mysqli_query($connection, "select destinasi.* from destinasi");

      $nomor = 1;
      while($row = mysqli_fetch_array($query))
      {    
      ?>    
    <tr>
      <td><?php echo $nomor;?></td>
      <td><?php echo $row['kategoriKODE'];?></td>
      <td><?php echo $row['kategoriNAMA'];?></td>
      <td><?php echo $row['kategoriKET'];?></td>
      <td><?php echo $row['kategoriREFERENCE'];?></td>

      <td width="5px">
        <a href="editwisatadash.php?ubah=<?php echo $row["kategoriKODE"]?>"
        class="btn btn-success btn-sm" title="edit">

        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg></td>

        <td width="5px">
            <a href="kategorihapus.php?hapus=<?php echo $row["kategoriKODE"]?>"
            class="btn btn-danger btn-sm" title="hapus">
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6Z"/>
  <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1ZM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118ZM2.5 3h11V2h-11v1Z"/>
</svg></td>

    </tr>
  <?php $nomor = $nomor + 1; ?> 
  <?php } ?>
  </tbody>
</table>


  <!--akhir -->
	
	

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>