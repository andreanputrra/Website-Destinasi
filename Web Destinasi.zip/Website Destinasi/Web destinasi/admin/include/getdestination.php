<?php
// Include file konfigurasi database
include "include/config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $destinationID = $_POST['id'];

    // Query untuk mendapatkan daftar destinasi berdasarkan ID
    $query = mysqli_query($connection, "SELECT * FROM destinasiwisata WHERE id = $destinationID");

    // Tampilkan daftar destinasi
    if ($query) {
        while ($row = mysqli_fetch_assoc($query)) {
            // Tampilkan data destinasi sesuai kebutuhan Anda
            echo "<p>{$row['nama_destinasi']}</p>";
            // Tambahkan elemen HTML lainnya sesuai kebutuhan
        }
    } else {
        echo "Gagal mengambil data destinasi.";
    }
}
?>
