<?php
    include 'include/config.php';
    
    if(isset($_GET['ubah'])) {
        $kodedestinasi = $_GET['ubah'];
        
        // Query untuk mendapatkan data destinasi yang akan diubah
        $editdestinasi = mysqli_query($connection, "SELECT * FROM destinasiwisata WHERE destinasiKODE = '$kodedestinasi'");
        $rowedit = mysqli_fetch_array($editdestinasi);
        
        // Query untuk mendapatkan data kategori wisata
        $datakategori = mysqli_query($connection, "SELECT * FROM kategoriwisata");
        
        if(isset($_POST['Simpan'])) {
            $destinasiKODE = $_POST['kodedestinasi'];
            $destinasiNAMA = $_POST['namadestinasi'];
            $kategoriWISATA = $_POST['destinasikategori'];
            
            $namafile = $_FILES['file']['name'];
            $file_tmp = $_FILES['file']['tmp_name'];
            $ekstensifile = pathinfo($namafile, PATHINFO_EXTENSION);
            
            if(!empty($namafile)) {
                // Jika ada file yang diunggah, simpan ke direktori
                move_uploaded_file($file_tmp, "images/" . $namafile);
                
                // Update data destinasi termasuk foto jika ada perubahan
                mysqli_query($connection, "UPDATE destinasiwisata SET destinasiNAMA = '$destinasiNAMA', kategoriWISATA = '$kategoriWISATA', fotodestinasi = '$namafile' WHERE destinasiKODE = '$destinasiKODE'");
            } else {
                // Jika tidak ada perubahan pada foto, update data lainnya tanpa memperbarui foto
                mysqli_query($connection, "UPDATE destinasiwisata SET destinasiNAMA = '$destinasiNAMA', kategoriWISATA = '$kategoriWISATA' WHERE destinasiKODE = '$destinasiKODE'");
            }
            $datakategori = mysqli_query($connection, "select * from kategoriwisata");

            // Setelah update selesai, alihkan pengguna kembali ke halaman destinasiadminpage.php
            echo "<script>window.location.href = 'destinasiadminpage.php';</script>";
            exit();
        }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Destinasi</title>
    <!-- Tambahkan link ke file CSS yang diperlukan di sini -->
</head>
<body>
<div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
        <form method="POST" enctype="multipart/form-data">
            <!-- Isi form dengan data destinasi yang akan diubah -->
            <div class="mb-3 row">
                <label for="kodedestinasi" class="col-sm-2 col-form-label">Kode Destinasi</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="kodedestinasi" id="kodedestinasi" value="<?php echo $rowedit["destinasiKODE"] ?>" readonly>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="namadestinasi" class="col-sm-2 col-form-label">Nama Destinasi</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="namadestinasi" id="namadestinasi" value="<?php echo $rowedit["destinasiNAMA"] ?>">
                </div>
            </div>

         

            <div class="mb-3 row">
                    <label for="destinasikategori" class="col-sm-2 col-form-label">Kategori Wisata</label>
                    <div class="col-sm-10">
                        <select class="form-control" name="destinasikategori" id="destinasikategori">
                            <option>Kategori Wisata</option>
                            <?php while($row = mysqli_fetch_array($datakategori))
                            {
                                ?>
                                <option value="<?php echo $row["kategoriKODE"]?>">
                                    <?php echo $row["kategoriKODE"]?>
                                    <?php echo $row["kategoriNAMA"]?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

            <div class="mb-3-row">
                <label for="file" class="col-sm-2 col-form-label">Foto Lokasi</label>
                <div class="col-sm-10">
                    <input type="file" id="file" name="file">
                    <p class="help-block">Field ini digunakan untuk unggah file</p>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-2"></div>
                <div class="col-sm-10">
                    <input type="submit" name="Simpan" value="Simpan" class="btn btn-secondary">
                    <a href="destinasiadminpage.php" class="btn btn-danger">Batal</a>
                </div>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('#destinasikategori').select2({
            closeOnSelect: true,
            allowClear: true,
            placeholder: 'Pilih Kategori Wisata'
        });
    });
</script>

</body>
</html>
<?php
    } else {
        // Tambahkan tindakan jika parameter 'ubah' tidak ada
    }
?>
