<?php
include 'include/config.php';

if (isset($_GET['ubah'])) {
    $orderKODE = $_GET['ubah'];
    $query = mysqli_query($connection, "SELECT * FROM ordertravel WHERE orderKODE = '$orderKODE'");
    $row = mysqli_fetch_assoc($query);
}

if (isset($_POST['Update'])) {
    $orderKODE = $_POST['orderKODE'];
    $orderNAMA = $_POST['orderNAMA'];
    $orderDESTINASI = $_POST['orderDESTINASI'];
    $kodeTRAVEL = $_POST['travelID'];

    // Lakukan query UPDATE di sini
    mysqli_query($connection, "UPDATE ordertravel SET orderNAMA='$orderNAMA', orderDESTINASI='$orderDESTINASI', kodeTRAVEL='$kodeTRAVEL' WHERE orderKODE='$orderKODE'");

    echo '<script>alert("Update successful!"); window.location.href = "travelorderdash.php";</script>';
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Order Travel</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css">
</head>
<body>
    <div class="container">
        <h1>Edit Order Travel</h1>
        <form method="POST">
            <!-- Menampilkan nilai saat ini -->
            <input type="hidden" name="orderKODE" value="<?php echo $row['orderKODE']; ?>">
            <div class="form-group">
                <label for="orderNAMA">Order Nama</label>
                <input type="text" class="form-control" name="orderNAMA" value="<?php echo $row['orderNAMA']; ?>" placeholder="Order Nama">
            </div>
            <div class="form-group">
                <label for="orderDESTINASI">Destinasi</label>
                <input type="text" class="form-control" name="orderDESTINASI" value="<?php echo $row['orderDESTINASI']; ?>" placeholder="Destinasi">
            </div>
            <div class="form-group">
                <label for="travelID">Travel Kode</label>
                <select class="form-control" name="travelID" id="travelID">
                    <option>Pilih Travel</option>
                    <?php 
                    $datatravel = mysqli_query($connection, "SELECT * FROM travel");
                    while($travel = mysqli_fetch_array($datatravel)) {
                    ?>
                        <option value="<?php echo $travel['kodeTRAVEL']; ?>" <?php if($travel['kodeTRAVEL'] == $row['kodeTRAVEL']) echo 'selected="selected"'; ?>>
                            <?php echo $travel['kodeTRAVEL'] . " - " . $travel['namaTRAVEL']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <button type="submit" name="Update" class="btn btn-primary">Update</button>
        </form>
    </div>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#travelID').select2({
                closeOnSelect:true,
                allowClear:true,
                placeholder:'Pilih Travel'
            });
        });
    </script>
</body>
</html>
