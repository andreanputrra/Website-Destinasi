<?php
    include "include/config.php";

    if(isset($_GET['hapus'])) {
        $hotel0136 = $_GET['hapus'];
        $query = mysqli_query($connection, "SELECT * FROM andreanpt WHERE hotel0136='$hotel0136'");
        $row = mysqli_fetch_assoc($query);
    }

    if(isset($_POST['HapusData'])) {
        $hotel0136 = $_POST['hotel0136'];
        mysqli_query($connection, "DELETE FROM andreanpt WHERE hotel0136='$hotel0136'");
        
    }
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Konfirmasi Hapus Data</h2>
        <p>Anda yakin ingin menghapus data hotel ini?</p>
        <form method="POST">
            <input type="hidden" name="hotel0136" value="<?php echo $row['hotel0136']; ?>">
            <button type="submit" class="btn btn-danger" name="HapusData">Hapus</button>
            <a href="hoteladmin.php" class="btn btn-secondary">Batal</a>
            <a href="hoteladmin.php" class="btn btn-third">Continue</a>

        </form>
    </div>
</body>
</html>
