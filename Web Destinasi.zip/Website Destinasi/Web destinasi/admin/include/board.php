<div class="row">
    <div class="col-xl-3 col-md-6">
        <div class="card bg-primary text-white mb-4">
            <div class="card-body">
                <?php
                include "include/config.php";
                $query = mysqli_query($connection, "SELECT COUNT(*) AS totalDestinasi FROM destinasiwisata");
                $data = mysqli_fetch_assoc($query);

                $totalDestinasi = $data['totalDestinasi']; 

                echo "<p class='card-title'>Total Destinasi Wisata :  $totalDestinasi </p>";
               
                ?>
            </div>
            <div id="destinationList">
            <div class="card-footer d-flex align-items-center justify-content-between">
            <a class="small text-white stretched-link view-details" href="#" data-id="1">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
            <script>
$(document).ready(function() {
    // Fungsi untuk menampilkan daftar destinasi
    function showDestinationList(destinationKODE) {
        // Lakukan permintaan AJAX untuk mendapatkan data destinasi
        $.ajax({
            url: 'getdestination.php', // Ganti dengan URL yang sesuai
            method: 'POST',
            data: { id: destinationKODE },
            success: function(response) {
                $('#destinationList').html(response);
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    }

    // Tambahkan event click pada link "View Details"
    $('.view-details').on('click', function(e) {
        e.preventDefault();
        var destinationID = $(this).data('id');
        showDestinationList(destinationKODE);
    });
});
</script>

            </div>

          
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card bg-warning text-white mb-4">
            <div class="card-body">Warning Card</div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="#">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card bg-success text-white mb-4">
            <div class="card-body">Success Card</div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="#">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card bg-danger text-white mb-4">
            <div class="card-body">Danger Card</div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="#">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
</div>
