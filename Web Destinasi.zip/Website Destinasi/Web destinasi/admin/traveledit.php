<?php
include "include/config.php";

if (isset($_GET['ubah'])) {
    $kodeTRAVEL = $_GET['ubah'];
    $query = mysqli_query($connection, "SELECT * FROM travel WHERE kodeTRAVEL = '$kodeTRAVEL'");
    $row = mysqli_fetch_assoc($query);
}

if (isset($_POST['Update'])) {
    $kodeTRAVEL = $_POST['inputkode'];
    $namaTRAVEL = $_POST['inputnama'];
    $destinasiTRAVEL = $_POST['inputalamat'];

    $namafile = $_FILES['fotoTRAVEL']['name'];
    $file_tmp = $_FILES["fotoTRAVEL"]["tmp_name"];

    // Path folder tempat menyimpan foto
    $target_dir = 'images/';

    // Ambil ekstensi file
    $ekstensifile = strtolower(pathinfo($namafile, PATHINFO_EXTENSION));

    // Cek apakah file yang diunggah adalah gambar
    $isImage = getimagesize($_FILES["fotoTRAVEL"]["tmp_name"]);

    if ($isImage !== false) {
        // Membuat nama file baru dengan kode TRAVEL + ekstensi file
        $newFileName = $kodeTRAVEL . "." . $ekstensifile;

        // Pindahkan file yang diunggah ke folder tujuan
        move_uploaded_file($file_tmp, $target_dir . $newFileName);

        // Perform the update query here
        mysqli_query($connection, "UPDATE travel SET namaTRAVEL='$namaTRAVEL', destinasiTRAVEL='$destinasiTRAVEL', fotoTRAVEL='$newFileName' WHERE kodeTRAVEL='$kodeTRAVEL'");

        echo '<script>alert("Update successful!"); window.location.href = "traveldash.php";</script>';
        exit();
    } else {
        echo '<script>alert("File yang diunggah bukan gambar!");</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Destinasi Travel</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h1>Edit Destinasi Travel</h1>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="inputkode" value="<?php echo $row['kodeTRAVEL']; ?>">
            <div class="form-group">
                <label for="inputnama">Nama Travel</label>
                <input type="text" class="form-control" id="inputnama" name="inputnama" value="<?php echo $row['namaTRAVEL']; ?>" placeholder="Nama Travel">
            </div>
            <div class="form-group">
                <label for="inputalamat">Destinasi Travel</label>
                <input type="text" class="form-control" id="inputalamat" name="inputalamat" value="<?php echo $row['destinasiTRAVEL']; ?>" placeholder="Alamat Travel">
            </div>
            <div class="form-group">
                <label for="fotoTRAVEL">Foto</label><br>
                <img src="images/<?php echo $row['fotoTRAVEL']; ?>" width="80"><br>
                <input type="file" id="fotoTRAVEL" name="fotoTRAVEL">
            </div>
            <button type="submit" name="Update" class="btn btn-primary">Update</button>
        </form>
    </div>
</body>

</html>
