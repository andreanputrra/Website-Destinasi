<?php
include "include/config.php";

if(isset($_GET['hapus'])) {
    $menuKODE = $_GET['hapus'];

    // Hapus data dari database
    $query = mysqli_query($connection, "DELETE FROM restorant WHERE menuKODE = '$menuKODE'");
    if ($query) {
        echo '<script>alert("Data berhasil dihapus!"); window.location.href = "restorandash.php";</script>';
        exit();
    } else {
        echo '<script>alert("Gagal menghapus data!"); window.location.href = "restorandash.php";</script>';
        exit();
    }
} else {
    echo "Tidak ada data yang dihapus.";
}
?>
