<?php
include "include/config.php";

if(isset($_GET['ubah'])) {
    $menuKODE = $_GET['ubah'];
    $query = mysqli_query($connection, "SELECT * FROM restorant WHERE menuKODE = '$menuKODE'");
    $data = mysqli_fetch_array($query);
    
    if(isset($_POST['Simpan'])) {
        $kodeMenu = $_POST['menuKODE']; // Ubah menjadi menuKODE sesuai dengan input
        $namaMenu = $_POST['namaMenu'];
        
        $namafile = $_FILES['fotoMenu']['name'];
        $file_tmp = $_FILES['fotoMenu']['tmp_name'];
        $ekstensifile = pathinfo($namafile, PATHINFO_EXTENSION);

        // Pastikan file yang diunggah adalah gambar JPG/JPEG
        if(($ekstensifile == "jpg" || $ekstensifile == "jpeg" || $ekstensifile == "JPG" || $ekstensifile == "JPEG") && getimagesize($file_tmp)) {
            $namafile = uniqid() . "." . $ekstensifile; // Menggunakan nama unik untuk file
            $upload_directory = "images/" . $namafile;

            // Pindahkan file yang diunggah ke direktori tujuan
            move_uploaded_file($file_tmp, $upload_directory);

            // Update data ke database
            mysqli_query($connection, "UPDATE restorant SET menuNAMA = '$namaMenu', menuFOTO = '$namafile' WHERE menuKODE = '$menuKODE'");
            echo '<script>alert("Update berhasil!"); window.location.href = "restorandash.php";</script>';
            exit();
        } else {
            echo '<script>alert("Format file tidak didukung!");</script>';
        }
    }
} else {
    echo "Menu tidak ditemukan.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Restoran</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <style>
        /* Tambahkan ruang */
        .form-group {
            margin-bottom: 15px;
        }
        .image-preview {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Restoran</h1>
        <div class="row">
            <div class="col-md-6">
                <form method="POST" enctype="multipart/form-data">
             
                    
                    <div class="form-group">
                        <label for="menuKODE" class="form-label">Menu Kode:</label>
                        <input type="text" id="menuKODE" class="form-control" name="menuKODE" value="<?php echo $data['menuKODE']; ?>">
                    </div>

                    <div class="form-group">
                        <label for="namaMenu" class="form-label">Nama Menu:</label>
                        <input type="text" id="namaMenu" class="form-control" name="namaMenu" value="<?php echo $data['menuNAMA']; ?>">
                    </div>
           

                    <div class="image-preview">
                        <label for="fotoMenu" class="form-label">Foto Menu:</label><br>
                        <img src="images/<?php echo $data['menuFOTO']; ?>" width="80"><br>
                        <input type="file" id="fotoMenu" name="fotoMenu">
                    </div>
                    
                    <input type="submit" name="Simpan" value="Simpan" class="btn btn-primary">
                    <a href="restorandash.php" class="btn btn-third">Continue</a>
                </form>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
</body>
</html>

