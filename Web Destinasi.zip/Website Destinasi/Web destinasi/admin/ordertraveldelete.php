<?php
include 'include/config.php';

if(isset($_GET['hapus'])) {
    $orderKODE = $_GET['hapus'];

    // Lakukan query DELETE untuk menghapus data sesuai dengan orderKODE yang dipilih
    mysqli_query($connection, "DELETE FROM ordertravel WHERE orderKODE = '$orderKODE'");

    echo '<script>alert("Data berhasil dihapus!"); window.location.href = "travelorderdash.php";</script>';
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hapus Order Travel</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Hapus Order Travel</h1>
        <!-- Tampilkan konfirmasi untuk menghapus data -->
        <p>Apakah Anda yakin ingin menghapus data ini?</p>
        <a href="travelorderdash.php" class="btn btn-secondary">Batal</a>
        <a href="ordertraveldelete.php?hapus=<?php echo $_GET['hapus']; ?>" class="btn btn-danger">Hapus</a>
    </div>
</body>
</html>
