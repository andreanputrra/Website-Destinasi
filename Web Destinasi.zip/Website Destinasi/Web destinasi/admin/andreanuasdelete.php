<?php
    include 'include/config.php';
    
    if(isset($_GET['hapus'])) {
        $kode_to_delete = $_GET['hapus'];
        
        $deleteQuery = "DELETE FROM andreanuas WHERE destinasiKODE = '$kode_to_delete'";
        
        if(mysqli_query($connection, $deleteQuery)) {
            header("Location: andreanuasdash.php"); // Redirect to desired page after successful delete
            exit();
        } else {
            echo "Error deleting data: " . mysqli_error($connection);
        }
    } else {
        echo "No identifier provided!";
        exit;
    }
?>
