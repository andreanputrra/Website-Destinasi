<!DOCTYPE html>
<html>
 
<?php
	include "include/config.php";
    
	if(isset($_POST['Simpan']))
	{
		$hotel0136 = $_POST['hotel0136'];
		$hotelnama = $_POST['hotelnama'];
        $hotelalamat = $_POST['hotelalamat'];
		$kategori0136 = $_POST['kategori0136'];

        $namafile = $_FILES['file']['name'];
        $file_tmp = $_FILES["file"]["tmp_name"];
      
        $ekstensifile = pathinfo($namafile, PATHINFO_EXTENSION);
        mysqli_query($connection, "INSERT INTO andreanpt (hotel0136, hotelnama, hotelalamat, kategori0136, hotelfoto) VALUES ('$hotel0136', '$hotelnama', '$hotelalamat', '$kategori0136', '$namafile')");
	
	} else {
        
        echo " " . mysqli_error($connection);
    }
?>
 
<head>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css"/>
</head>
 
<body>
<div class="row">
<div class="col-sm-1"></div>
<div class="col-sm-10">
<form method="POST" enctype="multipart/form-data">
<div class="mb-3 row">
<label for="hotel0136" class="col-sm-2 col-form-label">Kode Hotel</label>
<div class="col-sm-10">
<input type="text" class="form-control" id="hotel0136" name="hotel0136">
</div>
</div>
<div class="mb-3 row">
<label for="hotelnama" class="col-sm-2 col-form-label">Nama Hotel</label>
<div class="col-sm-10">
<input type="text" class="form-control" id="hotelnama" name="hotelnama" >
</div>
</div>
<div class="mb-3 row">
<label for="hotelalamat" class="col-sm-2 col-form-label">Alamat Hotel</label>
<div class="col-sm-10">
<input type="text" class="form-control" id="hotelalamat" name="hotelalamat">
</div>
</div>
<div class="mb-3 row">
<label for="kategori0136" class="col-sm-2 col-form-label">Kategori Kode</label>
<div class="col-sm-10">
<input type="text" class="form-control" id="kategori0136" name="kategori0136">
</div>

<!-- fptp lokasi -->
<div class="mb-3-row">
   <label for="file" class="col-sm-2 col-form-label">Foto Lokasi</label>
   <div class="col-sm-10">
    <input type="file" id="file" name="file">
    <p class="help-block">Field ini digunakan untuk unggah file</p>
   </div>
  </div>
</div>


<div class="form-group row">
<div class="col-sm-2"></div>
<div class="col-sm-10">
<input type="submit" class="btn btn-primary" value="Simpan" name="Simpan">
<input type="reset" class="btn btn-secondary" value="Batal" name="Batal">
</div>
</div>
</form>
<br><br>

<form method="POST">
    <div class="form-group row mb-2">
        <label for="search_nama" class="col-sm-3">Nama Hotel</label>
        <div class="col-sm-6">
            <input type="text" name="search_nama" class="form-control" id="search_nama" value="<?php echo isset($_POST['search_nama']) ? $_POST['search_nama'] : ''; ?>" placeholder="Cari nama hotel">          
        </div>
        <input type="submit" name="kirim_nama" class="col-sm-1 btn btn-primary" value="Search">
    </div>

 

    <div class="form-group row mb-2">
        <label for="search_alamat" class="col-sm-3">Alamat Hotel</label>
        <div class="col-sm-6">
            <input type="text" name="search_alamat" class="form-control" id="search_alamat" value="<?php echo isset($_POST['search_alamat']) ? $_POST['search_alamat'] : ''; ?>" placeholder="Cari Alamat hotel">        
        </div>
        <input type="submit" name="kirim_alamat" class="col-sm-1 btn btn-primary" value="Search">
    </div>
</form>




 
<div class="jumbotron mt-5">
<h1 class="display-5">Hasil entri data Hotel</h1>
</div>
 
<table class="table table-hover table-dark">
<thead>
<tr>
<th scope="col">No</th>
<th scope="col">Kode Hotel</th>
<th scope="col">Nama Hotel</th>
<th scope="col">Alamat Hotel</th>
<th scope="col">Kategori Kode</th>
<th scope="col">Foto Lokasi</th>

<th colspan="2" style="text-align" center">Aksi</th>
</tr>
</thead>
<tbody>
<?php
if (isset($_POST["kirim_nama"])) {
    $nama_hotel = $_POST['search_nama'];
    $query = mysqli_query($connection, "SELECT * FROM andreanpt WHERE hotelnama LIKE '%$nama_hotel%'");
} elseif (isset($_POST["kirim_alamat"])) {
    $alamat_hotel = $_POST['search_alamat'];
    $query = mysqli_query($connection, "SELECT * FROM andreanpt WHERE hotelalamat LIKE '%$alamat_hotel%'");
} else {
    $query = mysqli_query($connection, "SELECT andreanpt.* FROM andreanpt");
}


$nomor = 1;
while($row = mysqli_fetch_array($query))
{
?>
<tr>
<td><?php echo $nomor; ?></td>
<td><?php echo $row['hotel0136']; ?></td>
<td><?php echo $row['hotelnama']; ?></td>
<td><?php echo $row['hotelalamat']; ?></td>
<td><?php echo $row['kategori0136']; ?></td>
<td>
      <?php if(is_file("images/".$row['hotelfoto']))
      { ?>
       <img src="images/<?php echo $row['hotelfoto']?>" width="80">
      <?php } else
       echo "<img src='images/noimage.png' width='80'>"
      ?>
     </td>

<td width=3px>
<a href="editdashboard.php?ubah=<?php echo $row["hotel0136"]?>"
class="btn btn-success btn-sm" title="edit">
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
<path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
<path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg>
</td>
<td width=3px>
<a href="hapushoteldash.php?hapus=<?php echo $row["hotel0136"]?>"
class="btn btn-danger btn-sm" title="hapus">
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
<path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6Z"/>
<path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1ZM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118ZM2.5 3h11V2h-11v1Z"/>
</svg>
</td>
</tr>
<?php $nomor = $nomor + 1; ?>
<?php } ?>
</tbody>
</table>
 
</div>
</div> <!--penutup div buat form-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
</body>
</html>
 