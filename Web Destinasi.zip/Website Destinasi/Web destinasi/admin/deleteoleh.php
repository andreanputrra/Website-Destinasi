<?php
    include "include/config.php";

    if(isset($_GET['hapus'])) {
        $kode = $_GET['hapus'];

        $query = mysqli_query($connection, "DELETE FROM oleholeh WHERE pusatKODE='$kode'");
        
        if($query) {
            echo "<script>alert('Data berhasil dihapus'); window.location='oleholehdash.php';</script>";
        } else {
            echo "<script>alert('Gagal menghapus data');</script>";
        }
    }
?>
