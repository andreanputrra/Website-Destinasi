<?php
include "include/config.php";

if(isset($_GET['ubah'])) {
    $kategoriKODE = $_GET['ubah'];
    
    if(isset($_POST['Update'])) {
        $kategoriNAMA = $_POST['inputKategoriNama'];
        $kategoriKET = $_POST['inputKategoriKet'];
        $kategoriREFERENCE = $_POST['inputKategoriReference'];
        
        $query = "UPDATE kategoriwisata SET kategoriNAMA='$kategoriNAMA', kategoriKET='$kategoriKET', kategoriREFERENCE='$kategoriREFERENCE' WHERE kategoriKODE='$kategoriKODE'";
        $result = mysqli_query($connection, $query);
        
        if($result) {
            echo "<script>alert('Data berhasil diupdate');window.location='kategoriwisatadash.php';</script>";
        } else {
            echo "<script>alert('Gagal mengupdate data');</script>";
        }
    }

    $query = mysqli_query($connection, "SELECT * FROM kategoriwisata WHERE kategoriKODE='$kategoriKODE'");
    $row = mysqli_fetch_assoc($query);
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Edit Kategori Wisata</title>
</head>
<body>

<div class="col-sm-2"></div>

<div class="col-sm-10">
    <form method="POST" action="">
        <input type="hidden" name="kategoriKODE" value="<?php echo $row['kategoriKODE']; ?>">
        
        <div class="form-group row">
            <label for="kategoriNAMA" class="col-sm-3 col-form-label">Nama Kategori Wisata</label>
            <div class="col-sm-7">
                <input type="text" class="form-control" id="kategoriNAMA" name="inputKategoriNama" value="<?php echo $row['kategoriNAMA']; ?>" placeholder="Inputkan Nama Kategori Wisata">
            </div>
        </div>

        <div class="form-group row">
            <label for="kategoriKET" class="col-sm-3 col-form-label">Keterangan Kategori Wisata</label>
            <div class="col-sm-7">
                <input type="text" class="form-control" id="kategoriKET" name="inputKategoriKet" value="<?php echo $row['kategoriKET']; ?>" placeholder="Keterangan Kategori Wisata">
            </div>
        </div>

        <div class="form-group row">
            <label for="kategoriREFERENCE" class="col-sm-3 col-form-label">Reference Kategori Wisata</label>
            <div class="col-sm-7">
                <input type="text" class="form-control" id="kategoriREFERENCE" name="inputKategoriReference" value="<?php echo $row['kategoriREFERENCE']; ?>" placeholder="Referensi Kategori Wisata">
            </div>
        </div>

        <div class="form-group row">
            <div class="col-sm-0"></div>
            <div class="col-sm-5">
                <input type="submit" name="Update" value="Update" class="btn btn-secondary">
                <input type="reset" class="btn btn-success" value="Batal" name="Batal">
            </div>
        </div>
    </form>
</div>

</body>
</html>
<?php } ?>
