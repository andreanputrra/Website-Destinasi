<?php
include "include/config.php";

if(isset($_GET['hapus'])) {
    $beritaID = $_GET['hapus'];
    
    $result = mysqli_query($connection, "DELETE FROM berita WHERE beritaID='$beritaID'");
    
    if ($result) {
        echo '<script>alert("Data berhasil dihapus");</script>';
        echo '<script>window.location.href = "beritadash.php";</script>';
    } else {
        echo '<script>alert("Gagal menghapus data");</script>';
    }
}
?>
