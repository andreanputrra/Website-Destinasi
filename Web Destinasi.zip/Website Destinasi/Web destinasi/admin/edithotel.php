<?php
    include "include/config.php";

    if(isset($_POST['Simpan']))
    {
        $hotel0136 = $_POST['hotel0136'];
        $hotelnama = $_POST['hotelnama'];
        $hotelalamat = $_POST['hotelalamat'];
        $kategori0136 = $_POST['kategori0136'];

        $namafile = $_FILES['file']['name'];
        $file_tmp = $_FILES["file"]["tmp_name"];
      
        $ekstensifile = pathinfo($namafile, PATHINFO_EXTENSION);

        $update_query = "UPDATE andreanpt 
                         SET hotelnama = '$hotelnama', 
                             hotelalamat = '$hotelalamat', 
                             kategori0136 = '$kategori0136', 
                             hotelfoto = '$namafile' 
                         WHERE hotel0136 = '$hotel0136'";

        $result = mysqli_query($connection, $update_query);

        if($result) {
            // Redirect if the update is successful
            echo "<script>window.location.href = 'hoteladmin.php';</script>";
            exit();
        } else {
            // Display error if the update fails
            echo "Error: " . mysqli_error($connection);
        }
    }

    $hotelkode = $_GET["ubah"];
    $edit_hotel = mysqli_query($connection, "SELECT * FROM andreanpt WHERE hotel0136 = '$hotelkode'");
    $rowedit = mysqli_fetch_array($edit_hotel);
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css"/>
</head>
<body>
<div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3 row">
                <label for="hotel0136" class="col-sm-2 col-form-label">Kode Hotel</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="hotel0136" name="hotel0136" value="<?php echo $rowedit["hotel0136"]; ?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="hotelnama" class="col-sm-2 col-form-label">Nama Hotel</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="hotelnama" name="hotelnama" value="<?php echo $rowedit["hotelnama"]; ?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="hotelalamat" class="col-sm-2 col-form-label">Alamat Hotel</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="hotelalamat" name="hotelalamat" value="<?php echo $rowedit["hotelalamat"]; ?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="kategori0136" class="col-sm-2 col-form-label">Kategori Kode</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="kategori0136" name="kategori0136" value="<?php echo $rowedit["kategori0136"]; ?>">
                </div>
            </div>

            <!-- File input for photo -->
            <div class="mb-3-row">
                <label for="file" class="col-sm-2 col-form-label">Foto Lokasi</label>
                <div class="col-sm-10">
                    <input type="file" id="file" name="file">
                    <p class="help-block">Field ini digunakan untuk unggah file</p>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-2"></div>
                <div class="col-sm-10">
                    <input type="submit" class="btn btn-primary" value="Simpan" name="Simpan">
                    <a href="destinasiadminpage.php" class="btn btn-secondary">Batal</a>
                </div>
            </div>
        </form>
    </div>
</div>
    <!-- Rest of your HTML content -->
</body>
</html>
