<?php
include "include/config.php";

if(isset($_GET['hapus'])) {
    $kategoriKODE = $_GET['hapus'];

    $query = "DELETE FROM kategoriwisata WHERE kategoriKODE='$kategoriKODE'";
    $result = mysqli_query($connection, $query);

    if($result) {
        echo "<script>alert('Data berhasil dihapus');window.location='kategoriwisatadash.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus data');</script>";
    }
}
?>
