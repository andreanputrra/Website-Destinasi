<?php
include "include/config.php";

if(isset($_GET['hapus'])) {
    $kodeTRAVEL = $_GET['hapus'];
    
    // Query untuk menghapus data berdasarkan kode travel
    mysqli_query($connection, "DELETE FROM travel WHERE kodeTRAVEL = '$kodeTRAVEL'");
    
    // Redirect kembali ke halaman traveldash.php setelah penghapusan
    header("Location: traveldash.php");
    exit();
} else {
    echo "Tidak ada data yang dipilih untuk dihapus.";
}
?>
